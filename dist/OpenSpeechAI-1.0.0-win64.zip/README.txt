OpenSpeech AI 1.0.0 — Windows x64
================================

Portable, fully offline speech recognition (Persian + English) and
Persian<->English translation. No installer, no runtime, no network access.

Run
    OpenSpeechAI.exe

The program creates its data folder on first start:
    %LOCALAPPDATA%\OpenSpeechAI

Everything (models, transcripts, audio copies) stays inside that folder.
Settings are stored in settings.ini next to the data root.

Requirements
    Windows 10 or 11, 64-bit. 350 MB RAM, ~50 MB free disk.

Verified
    SHA-256 of OpenSpeechAI.exe is listed in checksums-1.0.0.txt

Licence
    GPL-3.0-or-later. Bundled fonts: Vazirmatn (SIL OFL 1.1), see LICENSE-Vazirmatn.txt
