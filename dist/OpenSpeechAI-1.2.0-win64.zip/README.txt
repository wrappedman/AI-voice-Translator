OpenSpeech AI 1.2.0 — Windows x64
================================

Portable offline speech recognition and multilingual translation.
No installer, no account, no bundled model weights.

Run
    OpenSpeechAI.exe

Keep the whole folder together
    OpenSpeechAI.exe
    OpenSpeechWorker.exe
    assets\fonts\Vazirmatn-*.ttf
    assets\catalog.json

    OpenSpeechWorker.exe must sit next to OpenSpeechAI.exe. It runs the
    neural translation / language-identification engines in a separate
    process so a model failure cannot take down the window.

First run
    The application starts with NO installed models. Open Models, download
    one speech model (Whisper), one translation model (Qwen GGUF) and the
    language-identification model (fastText LID 176), then activate each.
    Transcription, translation and live features stay disabled until all
    three categories have an active model. Downloads are verified against
    pinned SHA-256 hashes and installed inactive; activation is explicit.

The program creates its data folder on first start:
    %LOCALAPPDATA%\OpenSpeechAI

Everything (downloaded models, transcripts, audio copies) stays there.
Settings are stored in settings.ini inside the data root.

Requirements
    Windows 10 version 1903 or newer / Windows 11, 64-bit.
    8 GB RAM minimum recommended for the Qwen2.5 3B translation model.
    Several GB of free disk for the models you choose to download.
    Internet access only when you press Download; inference is offline.

Verified
    SHA-256 of OpenSpeechAI.exe, OpenSpeechWorker.exe and the zip are listed
    in checksums-1.2.0.txt. Model downloads are verified separately against
    the catalog hashes before installation.

Licence
    GPL-3.0-or-later. Bundled fonts: Vazirmatn (SIL OFL 1.1).
    Third-party engine sources: llama.cpp (MIT), fastText (MIT),
    nlohmann/json (MIT). Model weights have their own licences listed in
    the Models screen and assets/catalog.json.
