OpenSpeech AI 1.6.0 — Windows x64
================================

Portable offline speech recognition and multilingual translation.
No installer, no account, no bundled model weights.

Run
    OpenSpeechAI.exe

Put the folder somewhere writable
    C:\OpenSpeechAI or your Desktop is fine. Do not run it from inside the
    ZIP, and avoid C:\Program Files unless you have write access there.

    OpenSpeechAI.exe
    OpenSpeechWorker.exe        (also embedded inside OpenSpeechAI.exe)
    assets\fonts\Vazirmatn-*.ttf
    assets\catalog.json

    The worker runs the neural translation / language-identification engines
    in a separate process. It is embedded in OpenSpeechAI.exe and extracted
    to data\Cache on first use, so activation works even if you copy the
    exe on its own. Worker diagnostics go to data\Logs\worker.log.

First run
    The interface opens in Persian with the light theme.
    Settings -> Models folder chooses where model files live; Sync registers the
    verified files already in that folder. Delete on an installed row removes
    both the file and its database record.
    If a model fails to activate, the message quotes the real reason and
    data\Logs\worker.log has the full trace.
    The application starts with NO installed models. Open Models, download
    one speech model (Whisper), one translation model (Qwen GGUF) and one
    language-identification model (fastText LID 176 or GlotLID v4), then activate each.
    Transcription, translation and live features stay disabled until all
    three categories have an active model. The window header always names
    the active model in each category.

    The catalogue offers 8 Whisper variants, 7 Qwen2.5 translation quants and
    6 language-identification models (fastText LID 176 plus GlotLID v4, from
    0.9 MB to 747 MB). Each row states the approximate RAM needed and marks
    light models. Downloads show their percentage, can be cancelled, and are
    verified against pinned sizes and SHA-256 hashes before being installed inactive.
    There is no local-file import: only the official catalogue installs.

Everything the program writes lives next to the executable:
    <folder with OpenSpeechAI.exe>\data\
        Models\  Downloads\  Database\  Logs\  Licenses\  Audio\  Cache\ ...
        settings.ini

Nothing is created in AppData. An older %LOCALAPPDATA%\OpenSpeechAI profile
is moved into data\ once on first start, and removed when it is empty.

Requirements
    Windows 10 version 1903 or newer / Windows 11, 64-bit.
    Light models run on 2-4 GB RAM; the Qwen2.5 3B translator recommends 8 GB.
    Several GB of free disk for the models you choose to download.
    Internet access only when you press Download; inference is offline.

Verified
    SHA-256 of OpenSpeechAI.exe, OpenSpeechWorker.exe and the zip are listed
    in checksums-1.6.0.txt. Model downloads are verified separately against
    the catalog hashes before installation.

Developer
    behnam ehsani — inbox.ehsani@gmail.com
    https://github.com/wrappedman/AI-voice-Translator

Licence
    GPL-3.0-or-later. Bundled fonts: Vazirmatn (SIL OFL 1.1).
    Third-party engine sources: llama.cpp (MIT), fastText (MIT),
    nlohmann/json (MIT). Model weights have their own licences listed in
    the Models screen and assets/catalog.json.
